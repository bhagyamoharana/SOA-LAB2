package soa5_client_2018;

public class SOA5_Client_2018 {

    public static void main(String[] args) {
        //System.out.println(getAllParts());
        //System.out.println(getOnePart("A012345"));
        //System.out.println(deleteAllParts());
        //System.out.println(deleteOnePart("A054321"));
        //System.out.println(updateOnePart("A054321"));
        System.out.println(addOnePart("A054321"));
    }

    private static String getAllParts() {
        soap.hardcoded.PartsWS_Service service = new soap.hardcoded.PartsWS_Service();
        soap.hardcoded.PartsWS port = service.getPartsWSPort();
        return port.getAllParts();
    }

    private static String getOnePart(java.lang.String partNo) {
        soap.hardcoded.PartsWS_Service service = new soap.hardcoded.PartsWS_Service();
        soap.hardcoded.PartsWS port = service.getPartsWSPort();
        return port.getOnePart(partNo);
    }

    private static String deleteAllParts() {
        soap.hardcoded.PartsWS_Service service = new soap.hardcoded.PartsWS_Service();
        soap.hardcoded.PartsWS port = service.getPartsWSPort();
        return port.deleteAllParts();
    }

    private static String deleteOnePart(java.lang.String partNo) {
        soap.hardcoded.PartsWS_Service service = new soap.hardcoded.PartsWS_Service();
        soap.hardcoded.PartsWS port = service.getPartsWSPort();
        return port.deleteOnePart(partNo);
    }

    private static String updateOnePart(java.lang.String partNo) {
        soap.hardcoded.PartsWS_Service service = new soap.hardcoded.PartsWS_Service();
        soap.hardcoded.PartsWS port = service.getPartsWSPort();
        return port.updateOnePart(partNo);
    }

    private static String addOnePart(java.lang.String partNo) {
        soap.hardcoded.PartsWS_Service service = new soap.hardcoded.PartsWS_Service();
        soap.hardcoded.PartsWS port = service.getPartsWSPort();
        return port.addOnePart(partNo);
    }
    
}
