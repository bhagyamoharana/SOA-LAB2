
package soap.hardcoded;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "PartsWS")
public class PartsWS {

    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getAllParts")
    public String getAllParts() {
       StringBuffer buffer = new StringBuffer();
       buffer.append("<parts>\n");
       buffer.append("<part>123</part>\n");
       buffer.append("<part>456</part>\n");
       buffer.append("<part>789</part>\n");
       buffer.append("<parts>\n");
       return buffer.toString();
       
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getOnePart")
    public String getOnePart(@WebParam(name = "partNo") String partNo) {
        //TODO write your implementation code here:
        String s = "<part id='" +partNo+"'/>";
        return s;
    }
    
     
    @WebMethod(operationName = "deleteAllParts")
    public String deleteAllParts() {
        //TODO write your implementation code here:
        
        return "<allPartsDeleted/>";
    }
    
    @WebMethod(operationName = "deleteOnePart")
    public String deleteOnePart(@WebParam(name = "partNo") String partNo) {
        //TODO write your implementation code here:
        String s = "<partDeleted id='" +partNo+"'/>";
        return s;
    }
     @WebMethod(operationName = "updateOnePart")
    public String updateOnePart(@WebParam(name = "partNo") String partNo) {
        //TODO write your implementation code here:
        String s = "<partupdated id='" +partNo+"'/>";
        return s;
    }
     @WebMethod(operationName = "addOnePart")
    public String addOnePart(@WebParam(name = "partNo") String partNo) {
        //TODO write your implementation code here:
        String s = "<partadded id='" +partNo+"'/>";
        return s;
    }
}
